# Modular Curvometry
## Reprodução dos Resultados
1. Clone o repositório:
   ```bash
   git clone https://github.com/curvometry/core
